const Template = `
    <div>
        <router-view/>
    </div>
` 
export default {
    name : 'App',
    components : {
    } ,
    template : Template
  }