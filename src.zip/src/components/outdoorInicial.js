var Outdoor = [{
    name : 'outdoor',
    template : `
        <div id="outdoor-Inicial">
            <img src="../../assets/logoNomads.png"></img>
            <P>Login</P>
        </div>
    `
},
{
    name : 'outdoor',
    template : `
        <div id="outdoor-Inicial">
            <img src="../../assets/logoNomads.png"></img>
            <P>Cadastro</P>
        </div>
    `
},

]

export default Outdoor;