import Info from '../lib/Info.js';


var infoComponent = {
    name : "infoComponent",
    template : `
        <div id="infoComponent">
            <div id="descricao"> </div>
            <div id="area"> </div>
        <link rel="stylesheet" href="../styles/info.css">

        </div>
    `
}

export default infoComponent;